close all; clc
A = imread("Lenna.png");

for k= [2 5 20 50 80 100]
    R = A(:, :, 1);
    G = A(:, :, 2);
    B = A(:, :, 3);
    
    IR = im2double(R);
    IG = im2double(G);
    IB = im2double(B);
    
    [u1,s1,v1] = svd(IR);
    [u2,s2,v2] = svd(IG);
    [u3,s3,v3] = svd(IB);
 
    c1 = zeros(size(IR));
    c2 = zeros(size(IG));
    c3 = zeros(size(IB));
    
    for j=1:k
        c1 = c1 + u1(:, j) * s1(j, j) * v1(:, j)';
    end
    for j=1:k
        c2 = c2 + u2(:, j) * s2(j, j) * v2(:, j)';
    end
    for j=1:k
        c3 = c3 + u3(:, j) * s3(j, j) * v3(:, j)';
    end
    %imshow(c1);
    
    q(:, :, 1) = c1;
    q(:, :, 2) = c2;
    q(:, :, 3) = c3;
    h = figure;
    imshow(q)
    waitfor(h);
end

